//RPS Function
function rps(userChoice) {
    let randChoice = Math.random()      //first, a (pseudo)random number is generated for the computer choise
    let compChoice
    if (randChoice < 0.34) {            //the computer choice is then decided based which "section" between 0 and 1
        compChoice = "Rock"             //the number falls within (0-.33 Rock, .34-.66 Paper, .67-.99 Scissors)
    }
    else if (randChoice < 0.67) {
        compChoice = "Paper"
    }
    else if (randChoice < 1) {
        compChoice = "Scissors"
    }

    if (userChoice == compChoice) {             //same choice == tie, message given
        alert("It's a tie! Both you and the computer chose " + userChoice)
    }                                           //goes through each winning condition and sends message when won
    else if ((userChoice == "Rock" && compChoice != "Paper") || (userChoice == "Paper" && compChoice != "Scissors") || (userChoice == "Scissors" && compChoice != "Rock")) {
        alert("You win! The computer chose " + compChoice + ", and " + userChoice + " beats " + compChoice + ".")
    }
    else {                                      //if there is no win, the user loses, message given
        alert("You lost! The computer chose " + compChoice + ", and " + compChoice + " beats " + userChoice + ".")
    }
}
