/*Name this external file hover_script.js*/

function upDate(previewPic){
    document.getElementById('image').style.backgroundImage = "url(" + previewPic.src +")";  //replace main image with preview src
    document.getElementById('image').innerHTML = previewPic.alt;            //replace default text with preview imaage/s alt text
}

function unDo(){
    document.getElementById('image').style.backgroundImage = "url('')";                     //replace main image with default
    document.getElementById('image').innerHTML = "Hover over an image below to display here.";
                                                                            //replace image text with default text

}