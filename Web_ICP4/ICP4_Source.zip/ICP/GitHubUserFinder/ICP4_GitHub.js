$(document).ready(function(){

    $("#userSearch").keypress(function(event) {     //allows enter key to be pressed in text box to trigger submit button
        if (event.keyCode === 13) {
            event.preventDefault();
            $("#searchBtn").click();
        }
    });

    $("#searchBtn").click(function(){
        $("#response").empty();          //remove any previous data from div where results are to be displayed
        var HTMLCode;
        var input = $("#userSearch").val()
        console.log("Old Contents Removed");
        console.log("Username searched: " + input);
        $.ajax({
            url:"https://api.github.com/users/" + input,
            dataType: "jsonp",
            success : function( result )
            {
                console.log(result);                //for data visibility

                if(result.data.message == "Not Found") {
                    HTMLCode = "<h3>Search Results for: " + input + "</h3> <hr> </div>";
                    HTMLCode += "<div class='row'> <div class='col-md-12'></div>";
                    HTMLCode += "<h3>No Results for that search. Please try again.</h3>";
                    console.log("Incorrect Username")
                }

                else {
                    var uName = result.data.name;       //set vars for each item needed from API
                    var uID = result.data.id;
                    var profileURL = result.data.avatar_url;
                    var uLink = result.data.html_url;
                    //HTML script that is created using variables and assigned to HTMLCode string
                    HTMLCode = "<h3>Search Results for: " + input + "</h3> <hr> </div>";
                    HTMLCode += "<div class='row'> <div class='col-md-2'></div>";
                    HTMLCode += "<img class='col-md-2' id='proPic' src='' alt='Profile Picture'>";
                    HTMLCode += "<div class=\"col-md-1\"></div> <div id=\"info\" class=\"col-md-7\">"
                    HTMLCode += "<h2><span>User's Name:</span> " + uName + "</h2>";
                    HTMLCode += "<p id='userId'><span>User ID:</span> " + uID + "</p>";
                    HTMLCode += "</div> </div> <div class=\"row\">"
                    HTMLCode += "<a class=\"col-md-12\" href='' target='_blank'><span>GitHub Link:</span> " + uLink + "</a>";
                }

                $("#response").append(HTMLCode);         //HTML code is appended to response div
                $("#proPic").attr("src", profileURL);    //src and href are updated after appending for easier manipulation
                $("a").attr("href", uLink);
            }});
        console.log("Information received and added to document.")
    });
});